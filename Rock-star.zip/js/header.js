$(document).ready(function() {

    var main_id = $('main').attr('id');

    $('a#' + main_id).addClass('active-item');
});
