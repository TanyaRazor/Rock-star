<!DOCTYPE html>
<html lang="ru">

<?php include 'head.html';?>

<body>
<?php include 'header.html';?>

<main id="catalog">
  <div class="section-catalog">
    <div class="container-fluid section-catalog__container">
      <h2 class="header section-catalog__header">Каталог песен</h2>

    </div>
  </div>
</main>

<?php include 'footer.html';?>

</body>

</html>
