<!DOCTYPE html>
<html lang="ru">

<?php include 'head.html';?>

<body>

<?php include 'header.html';?>
<main id="gallery">
  <div class="section-gallery">
    <div class="container-fluid section-gallery__container">
      <h2 class="header section-gallery__header">Галерея</h2>
    </div>
  </div>
</main>

<?php include 'footer.html';?>

</body>

</html>
